#!/bin/sh

docker ps |grep httpd
docker ps |grep node
docker ps |grep mariadb

docker stop httpd
docker rm httpd

docker stop node
docker rm node

docker stop mariadb
docker rm mariadb


docker ps |grep httpd
docker ps |grep node
docker ps |grep mariadb
