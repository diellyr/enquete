const mysql      = require('mysql');
const connection = mysql.createConnection({
  host     : '192.168.0.140',
  port     : '3306',
  user     : 'root',
  password : 'senhadoroot',
  database : 'enquete'
});

connection.connect(function(err){
  if(err) return console.log(err);
  console.log('conectou!');
})
