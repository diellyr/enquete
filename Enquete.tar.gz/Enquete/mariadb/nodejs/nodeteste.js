var mysql = require('mysql');

var con = mysql.createConnection({
  host: "192.168.0.140",
  user: "root",
  password: "senhadoroot",
  database: "enquete"
});

con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM perguntas WHERE id like '1'", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    var rows = JSON.stringify(rows); 

  });
});
