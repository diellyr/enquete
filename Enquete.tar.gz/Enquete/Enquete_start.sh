#!/bin/sh
PWD=$(pwd)

docker run -it --name mariadb -v $PWD/mariadb:/var/lib/mysql -p 3306:3306 -d diellyr/enquete.mariadb
docker run -it --name node -v $PWD/nodejs:/root -p 3000:3000 -d diellyr/enquete.nodejs
docker run -it --name httpd -v $PWD/apache:/app -p 800:80 -d diellyr/enquete.http

docker ps |grep httpd
docker ps |grep node
docker ps |grep mariadb

