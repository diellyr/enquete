const mysql      = require('mysql');
const connection = mysql.createConnection({
  host     : '192.168.0.140',
  port     : '3306',
  user     : 'root',
  password : 'senhadoroot',
  database : 'enquete'
});

function addRows(conn){
  const sql = "INSERT INTO perguntas (id,questao,a,b,c,d) VALUES ?";
  const values = [
        [NULL,'questao1', '1','2','3','4'],
        [NULL,'questao2', '2','2','3','4'],
        [NULL,'questao3', '3','2','3','4']
      ];
  conn.query(sql, [values], function (error, results, fields){
          if(error) return console.log(error);
          console.log('adicionou registros!');
          conn.end();//fecha a conexão
      });
}
